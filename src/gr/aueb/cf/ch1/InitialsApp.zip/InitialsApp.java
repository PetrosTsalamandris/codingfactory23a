package gr.aueb.cf.ch1;

public class InitialsApp {
    public static void main(String[] args) {
        System.out.println("" +
                "********   ********\n" +
                "*      *      *\n" +
                "*      *      *\n" +
                "*      *      *\n" +
                "*      *      *\n");
    }
}
