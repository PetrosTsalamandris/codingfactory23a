package gr.aueb.cf.ch1;

public class IntsApp {
    public static void main(String[] args) {
        int num1 = 19;
        int num2 = 30;
        int sum = num1 + num2;
        sum = num1 + num2;
        System.out.println("Το αποτελεσμα της προσθεσης ειναι ισο με:" + sum );
    }
}
